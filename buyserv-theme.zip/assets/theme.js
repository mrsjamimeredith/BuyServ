
document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form[action='/contact#quote']");
  if (!form) return;

  const org = form.querySelector("input[name='org']");
  const needs = form.querySelector("textarea[name='needs']");
  const budget = form.querySelector("input[name='budget']");

  const showError = (element, message) => {
    let error = element.nextElementSibling;
    if (!error || !error.classList.contains("error-message")) {
      error = document.createElement("div");
      error.className = "error-message";
      element.parentNode.insertBefore(error, element.nextSibling);
    }
    error.textContent = message;
    element.classList.add("error");
  };

  const clearError = (element) => {
    let error = element.nextElementSibling;
    if (error && error.classList.contains("error-message")) {
      error.textContent = "";
    }
    element.classList.remove("error");
  };

  const validateField = (element, condition, message) => {
    if (condition) {
      clearError(element);
      return true;
    } else {
      showError(element, message);
      return false;
    }
  };

  org.addEventListener("input", () => {
    validateField(org, org.value.trim() !== "", "Organization name is required.");
  });

  needs.addEventListener("input", () => {
    validateField(needs, needs.value.trim() !== "", "Please describe your needs.");
  });

  budget.addEventListener("input", () => {
    validateField(budget, !budget.value || !isNaN(budget.value), "Budget must be a number.");
  });

  form.addEventListener("submit", function (e) {
    const isOrgValid = validateField(org, org.value.trim() !== "", "Organization name is required.");
    const isNeedsValid = validateField(needs, needs.value.trim() !== "", "Please describe your needs.");
    const isBudgetValid = validateField(budget, !budget.value || !isNaN(budget.value), "Budget must be a number.");

    if (!isOrgValid || !isNeedsValid || !isBudgetValid) {
      e.preventDefault();
    }
  });
});
